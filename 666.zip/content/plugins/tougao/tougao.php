﻿<?php
/*
Plugin Name:在线投稿
Version: 1.0
Plugin URL:http://
Description:一个简单的投稿功能二次美化
ForEmlog:5.3.1
Author:娃娃
Author URL: http://
*/

!defined('EMLOG_ROOT') && exit('access deined!');
//写入插件导航
function tougao_menu(){?><div class="sidebarsubmenu"><a href="./plugin.php?plugin=tougao">投稿设置</a></div>
<?php }
addAction('adm_sidebar_ext','tougao_menu');