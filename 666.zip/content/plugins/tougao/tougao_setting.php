﻿<?php
!defined('EMLOG_ROOT') && exit('access deined!');

function plugin_setting_view(){require_once 'sltg.php';?>

<div class="sltg">
<span style=" font-size:18px; font-weight:bold;">配置文件</span><?php if(isset($_GET['setting'])){echo "<span class='actived'>设置保存成功!</span>";}?><br />
<br />
<link href="<?php echo BLOG_URL;?>content/plugins/tougao/sltg.css" rel="stylesheet" type="text/css" />
<form action="plugin.php?plugin=tougao&action=setting" method="post">
<ul>

<li><h4>网站后台</h4>
<div class="one"><input type="text" class="txt" name="admin" value="<?php echo $config["admin"];?>" /></div>
<p>后台后缀，默认为admin</p>
</li>

<li><h4>名称</h4>
<div class="one name"><input type="text" id="name" name="name" value="<?php echo $config["name"];?>" /></div>
<p>显示在浏览器上面</p>
</li>

<li><h4>作者ID</h4>
<div class="one"><input type="text" class="txt" name="author" value="<?php echo $config["author"];?>" /></div>
<p>投稿作者ID</p>
</li>

<li><h4>置顶/草稿/审核</h4>
<div class="radio"><input type="checkbox" name="top" value="y" <?php if($config["top"]=='y'){echo 'checked="checked"';}?> /><label>首页置顶</label></div>
<div class="radio"><input type="checkbox" name="sortop" value="y" <?php if($config["sortop"]=='y'){echo 'checked="checked"';}?> /><label>分类置顶</label></div>
<div class="radio"><input type="checkbox" name="hide" value="y" <?php if($config["hide"]=='y'){echo 'checked="checked"';}?> /><label>放入草稿</label></div>
<div class="radio"><input type="checkbox" name="checked" value="n" <?php if($config["checked"] == 'n'){echo 'checked="checked"';} ?> /><label>文章需审核</label></div>
<p>打勾即为显示</p>
</li>

<li><h4>分类ID</h4>
<div class="one"><input type="text" name="sort" value="<?php echo $config["sort"];?>" /></div>
<p>“0” 代表分类选项在投稿页显示，大于0则指定具体分类ID</p>
</li>

<li><h4>验证码开关</h4>
<div class="radio"><input type="radio" name="code" value="yes" <?php if($config["code"] == 'yes'){echo 'checked="checked"';} ?> /><label>显示</label></div>
<div class="radio"><input type="radio" name="code" value="no" <?php if($config["code"]=='no'){echo 'checked="checked"';} ?> /><label>关闭</label></div>
<p><?php if($config["code"]=='yes'){echo '<b>验证码开启，请填写下面验证码内容</b>';}else{echo '已经关闭了验证码';}?></p>
</li>
<?php if($config["code"] == 'yes'){?>
<li><h4>验证码</h4>
<div class="one"> <label>验证码</label><input type="text" class="txt" name="yzm" value="<?php echo $config["yzm"];?>" /></div>
<div class="one"> <label>验证码答案</label><input type="text" class="txt" name="yzmda" value="<?php echo $config["yzmda"];?>" /></div>
</li><?php }?>

<li><h4>投稿开关</h4>
<div class="radio"><input type="radio" name="tgkg" value="yes" <?php if($config["tgkg"] == 'yes'){echo 'checked="checked"';} ?> /><label>开启</label></div>
<div class="radio"><input type="radio" name="tgkg" value="no" <?php if($config["tgkg"]=='no'){echo 'checked="checked"';} ?> /><label>关闭</label></div>
<p><?php if($config["tgkg"]=='yes'){echo '投稿开启';}else{echo '<b>已经关闭投稿，请填写下面暗号</b>';}?></p>
</li>

<?php if($config["tgkg"] == 'no'){?>
<li><h4>投稿暗号</h4>
<div class="one"> <label>暗号</label><input type="text" class="txt" name="ah" value="<?php echo $config["ah"];?>" /></div>
<p><b>关闭投稿后需要这个暗号才可以进行投稿，以防止恶意投稿</b></p>
</li><?php }?>

<div class="sl">
注意事项：以下不能出现引号“”，否则会出错。<br />
<textarea  type="text" name="zysx" style="margin:5px; width:95%;height:100px;"/><?php echo $config["zysx"];?></textarea>
<br /><br />
使用帮助：<br />
请复制投稿页面地址，加至导航栏或其它位置。感谢您的使用！<br />
投稿页面地址：<a href="<?php echo BLOG_URL;?>?plugin=tougao" target="_blank"><?php echo BLOG_URL;?>?plugin=tougao</a><br />

<br />
<font color="#FF0000">注意：首次使用请点【保存设置】启用默认参数，否则插件无法正常使用</font><br />
有文章投稿后可以清理数据缓存，步骤：后台--数据--更新缓存
<br />
</div>
</ul>
<input type="submit" class="button" name="submit" value="保存设置" style="margin-top:10px;" />
</form>
</div>
<?php }
function plugin_setting(){require_once 'sltg.php';
$name = $_POST["name"]==""?"在线投稿":$_POST["name"];
$admin = $_POST["admin"]==""?"admin":$_POST["admin"];
$author = $_POST["author"]==""?"2":$_POST["author"];
$top = $_POST["top"]==""?"n":$_POST["top"];
$sortop = $_POST["sortop"]==""?"n":$_POST["sortop"];
$hide = $_POST["hide"]==""?"n":$_POST["hide"];
$checked = $_POST["checked"]==""?"y":$_POST["checked"];
$sort = $_POST["sort"]==""?"0":$_POST["sort"];
$code = $_POST["code"]==""?"no":$_POST["code"];
$yzm = $_POST["yzm"]==""?"8+5=？":$_POST["yzm"];
$yzmda = $_POST["yzmda"]==""?"13":$_POST["yzmda"];
$tgkg = $_POST["tgkg"]==""?"yes":$_POST["tgkg"];
$ah = $_POST["ah"]==""?"sheli":$_POST["ah"];
$newConfig = '<?php
$config = array(
"name" => "'.$name.'",
"admin" => "'.$admin.'",
"author" => "'.$author.'",
"top" => "'.$top.'",
"sortop" => "'.$sortop.'",
"hide" => "'.$hide.'",
"checked" => "'.$checked.'",
"sort" => "'.$sort.'",
"code" => "'.$code.'",
"yzm" => "'.$yzm.'",
"yzmda" => "'.$yzmda.'",
"tgkg" => "'.$tgkg.'",
"ah" => "'.$ah.'",
"zysx" => "'.$_POST["zysx"].'",
);';
	echo $newConfig;
	@file_put_contents(EMLOG_ROOT.'/content/plugins/tougao/sltg.php', $newConfig);
}
?>