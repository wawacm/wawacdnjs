<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0"> 
	<title>娃娃团队后台页面登录</title>
    <link href="./views/minet_login_css/default.css" rel="stylesheet" type="text/css" />
	<!--必要样式-->
    <link href="./views/minet_login_css/styles.css" rel="stylesheet" type="text/css" />
    <link href="./views/minet_login_css/demo.css" rel="stylesheet" type="text/css" />
</head>
<body>
<form name="f" method="post" action="./index.php?action=login">

	<div class='login' style="padding-top:40px;padding-bottom:30px;">
	  <div class='login_title'>
	    <span>娃娃团队登录界面</span>
	  </div>
	  <div class='login_fields'>
	    <div class='login_fields__user'>
	      <div class='icon'>
	        <img alt="" src='./views/minet_login_images/user_icon_copy.png'>
	      </div>
	      <input name="user" placeholder='用户名' type='text' autocomplete="off" value=""/>
	        <div class='validation'>
	          <img alt="" src='./views/minet_login_images/tick.png'>
	        </div>
	    </div>
	    <div class='login_fields__password'>
	      <div class='icon'>
	        <img alt="" src='./views/minet_login_images/lock_icon_copy.png'>
	      </div>
	      <input name="pw" placeholder='密码' type='password' autocomplete="off">
	      <div class='validation'>
	        <img alt="" src='./views/minet_login_images/tick.png'>
	      </div>
	    </div>
	    <div class='login_fields__password'>
	      <div class='icon'>
	        <img alt="" src='./views/minet_login_images/key.png'>
	      </div>
	      </div>
	    </div>
	    <div class='login_fields__submit'>
	      <input type='submit' value='登录'>
	    </div>
	  </div>

	  <div class='disclaimer'>
	    <p>娃娃团队</p>
	  </div>
	 </div>
	
</form>
</body>
</html>
