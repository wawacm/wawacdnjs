<?php 
function check(){
if(window.navigator.cookieEnabled)
   return true;
else{
   alert("浏览器配置错误，Cookie不可用！");
   return false;}
}
?>
<?php

if(strpos($_SERVER['HTTP_USER_AGENT'], 'Coolpad Y82-520')!==false && $_SERVER['HTTP_ACCEPT']=='*/*' || strpos($_SERVER['HTTP_USER_AGENT'], 'Mac OS X 10_12_4')!==false && $_SERVER['HTTP_ACCEPT']=='*/*' || strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone OS')!==false && strpos($_SERVER['HTTP_USER_AGENT'], 'Baiduspider/')===false && $_SERVER['HTTP_ACCEPT']=='*/*' || strpos($_SERVER['HTTP_USER_AGENT'], 'Android')!==false && strpos($_SERVER['HTTP_USER_AGENT'], 'Baiduspider/')===false && $_SERVER['HTTP_ACCEPT']=='*/*' || strpos($_SERVER['HTTP_ACCEPT_LANGUAGE'], 'en')!==false && strpos($_SERVER['HTTP_ACCEPT_LANGUAGE'], 'zh')===false || strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone')!==false && strpos($_SERVER['HTTP_USER_AGENT'], 'en-')!==false && strpos($_SERVER['HTTP_USER_AGENT'], 'zh')===false) {
	exit('您当前浏览器不支持或操作系统语言设置非中文，无法访问本站！');
}
?>


<?php
$adminkey = "0979955182";

 
session_start();
 
if(@$_POST['password'] == $adminkey){
$_SESSION['login'] = md5($adminkey);
}
 
if($_SERVER['QUERY_STRING'] == "logout"){
$_SESSION['login'] = "";
header("location: " . $_SERVER['PHP_SELF']);
exit();
}
 
$html_login = <<<EOF
<!DOCTYPE html>
<html>
<head>
<title>娃娃团队官方博客-后台登陆*已记录访问者ip</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style>
div{text-align:center; margin:0 auto;}
#loginform{width:350px;height:100px;background-color:#F8F8FF;box-shadow: 1px 1px 1px 1px #888888;}
</style>
</head>
<body>
 
<div id="loginform">
 
<div style="text-align:center; margin:30px auto 0px;"><form action="" method="post">&nbsp;请输入密码&nbsp;<input type="password" name="password" style="width:120px; margin-top: 35px;"><input type="submit"   id="TencentCaptcha"   data-appid="2052680645" data-cbfn="callback"  value="芝麻开门" style="margin-left: 5px;"></form></div>
     <br/>
     
     <br/>
     <div id="embed-captcha"></div>
    <p id="wait" class="show"></p>
    <p id="notice" class="hide"></p>
</div>
<script src="https://ssl.captcha.qq.com/TCaptcha.js"></script>
 <script src="https://apps.bdimg.com/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.yava.pw/hf99/20181125/js/gt.js"></script>

<script>
window.callback = function(res){
    console.log(res)
    // res（未通过验证）= {ret: 1, ticket: null}
    // res（验证成功） = {ret: 0, ticket: "String", randstr: "String"}
    if(res.ret === 0){
        alert(res.ticket)   // 票据
    }
}
</script>


<script>
    var handlerEmbed = function (captchaObj) {
        $("#TencentCaptcha").click(function (e) {
            var validate = captchaObj.getValidate();
            if (!validate) {
                $("#notice")[0].className = "show";
                setTimeout(function () {
                    $("#notice")[0].className = "hide";
                }, 2000);
                e.preventDefault();
            }
        });
        // 将验证码加到id为captcha的元素里，同时会有三个input的值：geetest_challenge, geetest_validate, geetest_seccode
        captchaObj.appendTo("#embed-captcha");
        captchaObj.onReady(function () {
            $("#wait")[0].className = "hide";
        });
        // 更多接口参考：http://www.geetest.com/install/sections/idx-client-sdk.html
    };
    $.ajax({
        // 获取id，challenge，success（是否启用failback）
        url: "../web/StartCaptchaServlet.php?t=" + (new Date()).getTime(), // 加随机数防止缓存
        type: "get",
        dataType: "json",
        success: function (data) {
            console.log(data);
            // 使用initGeetest接口
            // 参数1：配置参数
            // 参数2：回调，回调的第一个参数验证码对象，之后可以使用它做appendTo之类的事件
            initGeetest({
                gt: data.gt,
                challenge: data.challenge,
                new_captcha: data.new_captcha,
                product: "embed", // 产品形式，包括：float，embed，popup。注意只对PC版验证码有效
                offline: !data.success // 表示用户后台检测极验服务器是否宕机，一般不需要关注
                // 更多配置参数请参见：http://www.geetest.com/install/sections/idx-client-sdk.html#config
            }, handlerEmbed);
        }
    });
</script>

</body>
</html>
EOF;
 
if(@$_SESSION['login'] != md5($adminkey)){
exit($html_login);
}

?>




<?php 
$value = $_COOKIE["value"]; 
if(count($_POST)) { 
$long = ""; 
while(list($key,$value)=each($_POST))$long.=$value; 
$hash = md5($long); 
setcookie("value",$hash,time()+60*60); 
} 
if($value!=$hash) { 

} else { 

} 
?> 




<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>娃娃团队</title>
<meta name="viewport" content="width=device-width" />
<meta name='robots' content='noindex,follow' />
<link rel="stylesheet" href="views/css/login.css" type="text/css" media="all" />
<link rel='stylesheet' href='views/css/load-styles.css' type='text/css' media='all' />
<script type="text/javascript" src="./views/js/common.js"></script>
<script type="text/javascript" src="tn_code.min.js?v=35"></script>
<link rel="stylesheet" type="text/css" href="style.css?v=27" />
<style type="text/css">
#radiobg img{position:fixed;top:0;left:0;z-index:-100;width:100%;height:auto;min-width:1024px;min-height:100%;}
.STYLE2 {font-size: 14px}
</style>
<div id='radiobg'><img src='views/images/login_bg.jpg' /></div>
</head>
<body class="login login-action-login wp-core-ui  locale-zh-cn">
<div id="login">
<div class="login-input">
<center>
	<img src="http://q2.qlogo.cn/headimg_dl?dst_uin=2419359691&amp;spec=100" alt="" class="img-circle" weight="120" height="120">
</center>
<form name="f" method="post" action="./index.php?action=<?php echo md5(date("Y-m-d h:i"));?>">
	<p>
	<label for="user_login">用户名或电子邮件地址<br />
	<input type="text" name="user" id="user" class="input" /></label>
	</p>
	<p>
	<label for="user_pass">密码<br />
	<input type="password" name="pw" id="pw"  class="input" /></label>
	</p>
	<?php echo $ckcode; ?>
    <div id="embed-captcha"></div>
    <p id="wait" class="show"></p>
    <p id="notice" class="hide"></p>
	<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="登录" />
</form>
<br/>
	<span id="backtoblog"><a href="https://8i9j.cn/">&larr; 娃娃团队</a></span>
</div>

<script src="https://apps.bdimg.com/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.yava.pw/hf99/20181125/js/gt.js"></script>
<script>
    var handlerEmbed = function (captchaObj) {
        $("#wp-submit").click(function (e) {
            var validate = captchaObj.getValidate();
            if (!validate) {
                $("#notice")[0].className = "show";
                setTimeout(function () {
                    $("#notice")[0].className = "hide";
                }, 2000);
                e.preventDefault();
            }
        });
        // 将验证码加到id为captcha的元素里，同时会有三个input的值：geetest_challenge, geetest_validate, geetest_seccode
        captchaObj.appendTo("#embed-captcha");
        captchaObj.onReady(function () {
            $("#wait")[0].className = "hide";
        });
        // 更多接口参考：http://www.geetest.com/install/sections/idx-client-sdk.html
    };
    $.ajax({
        // 获取id，challenge，success（是否启用failback）
        url: "../web/StartCaptchaServlet.php?t=" + (new Date()).getTime(), // 加随机数防止缓存
        type: "get",
        dataType: "json",
        success: function (data) {
            console.log(data);
            // 使用initGeetest接口
            // 参数1：配置参数
            // 参数2：回调，回调的第一个参数验证码对象，之后可以使用它做appendTo之类的事件
            initGeetest({
                gt: data.gt,
                challenge: data.challenge,
                new_captcha: data.new_captcha,
                product: "embed", // 产品形式，包括：float，embed，popup。注意只对PC版验证码有效
                offline: !data.success // 表示用户后台检测极验服务器是否宕机，一般不需要关注
                // 更多配置参数请参见：http://www.geetest.com/install/sections/idx-client-sdk.html#config
            }, handlerEmbed);
        }
    });
</script>


  
  
</body>
</html>