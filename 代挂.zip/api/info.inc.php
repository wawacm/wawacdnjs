<?php
//购买说明
$info_buy = '代挂激活码购买地址：<a target="_blank" href="http://baidu.com">http://baidu.com</a>';

//联系QQ
$info_qq = '66547997';

//第二个月续费另外赠送天数
$twice_free = 1;