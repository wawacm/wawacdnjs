<?php
return array (
  'mb' => 'view',
);

?>