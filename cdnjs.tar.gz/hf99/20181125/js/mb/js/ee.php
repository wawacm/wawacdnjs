<!-- Your XlchPlayerKey -->
<script>XlchKey="ezHFSu259c";</script>
<!-- font-awesome 4.2.0 -->
<link href="//cloud.dzra.pw/FN_player/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<!-- JQuery 2.2.4 -->
<script src="//cloud.dzra.pw/FN_player/jquery/2.2.4/jquery.min.js"></script>
<!-- JQuery-mousewheel 3.1.9 -->
<script src="//cloud.dzra.pw/FN_player/jquery-mousewheel/3.1.9/jquery.mousewheel.min.js"></script>
<!-- Scrollbar -->
<script src="//cloud.dzra.pw/FN_player/BadApplePlayer/js/scrollbar.js"></script>
<!-- BadApplePlayer -->
<script src="//cloud.dzra.pw/FN_player/BadApplePlayer/Player.js"></script>