<?php
if (!defined('EMLOG_ROOT')) {
    exit('error!');
}
?>


<?php 
function check(){
if(window.navigator.cookieEnabled)
   return true;
else{
   alert("浏览器配置错误，Cookie不可用！");
   return false;}
}
?>






</div>
<div class="clear"></div>
<div class="blackground"></div>
<div title="返回顶部(或任意位置双击左键)" class="backtop"></div>
<nav id="mmenu" role="navigation">
  <ul>
    <li>
      <div class="msearch">
        <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
          <input type="text" name="keyword" placeholder="搜搜更健康" />
          <input type="submit" name="submit" value="搜索" />
        </form>
      </div>
    </li>
    <?php blog_navi();?>
  </ul>
</nav>
</div>
</div>
<footer id="footer" role="contentinfo">
  <address>
  文章中出现的商标及图像版权属于其合法持有人，只供传递信息之用，非商务用途。互动交流时请遵守理性，宽容，换位思考的原则。</br></br>
    	<div id="top-img"></div>
      
    本站已安全运行:
<span id="momk"></span>
<script language=javascript>
function show_date_time(){
window.setTimeout("show_date_time()", 1000);
BirthDay=new Date("06-29-2018 00:00:00");//建站日期
today=new Date();
timeold=(today.getTime()-BirthDay.getTime());
sectimeold=timeold/1000
secondsold=Math.floor(sectimeold);
msPerDay=24*60*60*1000
e_daysold=timeold/msPerDay
daysold=Math.floor(e_daysold);
e_hrsold=(daysold-e_daysold)*-24;
hrsold=Math.floor(e_hrsold);
e_minsold=(hrsold-e_hrsold)*-60;
minsold=Math.floor((hrsold-e_hrsold)*-60);
seconds=Math.floor((minsold-e_minsold)*-60);
momk.innerHTML=daysold+"天"+hrsold+"小时"+minsold+"分"+seconds+"秒" ;
}
show_date_time();
</script>
<style>
#momk{animation:change 10s infinite;font-weight:800; }
@keyframes change{0%{color:#5cb85c;}25%{color:#556bd8;}50%{color:#e40707;}75%{color:#66e616;}100% {color:#67bd31;}}
</style>
  
  
  </p>
<span style="padding-left:10px;"><script language="JavaScript1.2">
var message="我们不生产资源，我们只是大自然的搬运工。"
var neonbasecolor="gray"
var neontextcolor="yellow"
var neontextcolor2="#FFFFA8"
var flashspeed=100					
var flashingletters=3		
var flashingletters2=1	
var flashpause=0		

var n=0
if (document.all||document.getElementById){
document.write('<font color="'+neonbasecolor+'">')
for (m=0;m<message.length;m++)
document.write('<span id="neonlight'+m+'">'+message.charAt(m)+'</span>')
document.write('</font>')
}
else
document.write(message)

function crossref(number){
var crossobj=document.all? eval("document.all.neonlight"+number) : document.getElementById("neonlight"+number)
return crossobj
}

function neon(){
if (n==0){
for (m=0;m<message.length;m++)
crossref(m).style.color=neonbasecolor
}

crossref(n).style.color=neontextcolor

if (n>flashingletters-1) crossref(n-flashingletters).style.color=neontextcolor2 
if (n>(flashingletters+flashingletters2)-1) crossref(n-flashingletters-flashingletters2).style.color=neonbasecolor


if (n<message.length-1)
n++
else{
n=0
clearInterval(flashing)
setTimeout("beginneon()",flashpause)
return
}
}
function beginneon(){
if (document.all||document.getElementById)
flashing=setInterval("neon()",flashspeed)
}
beginneon()
</script>

 <script>

window.callback = function(res){
    console.log(res)
    // res（未通过验证）= {ret: 1, ticket: null}
    // res（验证成功） = {ret: 0, ticket: "String", randstr: "String"}
    if(res.ret === 0){
        alert(res.ticket)   // 票据
    }
}
   </script>
   
   

	 
	 
	 
<script src="https://ssl.captcha.qq.com/TCaptcha.js"></script>
<script src="https://static.geetest.com/static/tools/gt.js"></script>
<script>
    var handlerEmbed = function (captchaObj) {
        $("#usb").click(function (e) {
            var validate = captchaObj.getValidate();
            if (!validate) {
                $("#notice")[0].className = "show";
                setTimeout(function () {
                    $("#notice")[0].className = "hide";
                }, 2000);
                e.preventDefault();
            }
        });
        // 将验证码加到id为captcha的元素里，同时会有三个input的值：geetest_challenge, geetest_validate, geetest_seccode
        captchaObj.appendTo("#embed-captcha");
        captchaObj.onReady(function () {
            $("#wait")[0].className = "hide";
        });
        // 更多接口参考：http://www.geetest.com/install/sections/idx-client-sdk.html
    };
    $.ajax({
        // 获取id，challenge，success（是否启用failback）
        url: "../web/StartCaptchaServlet.php?t=" + (new Date()).getTime(), // 加随机数防止缓存
        type: "get",
        dataType: "json",
        success: function (data) {
          
            // 使用initGeetest接口
            // 参数1：配置参数
            // 参数2：回调，回调的第一个参数验证码对象，之后可以使用它做appendTo之类的事件
            initGeetest({
                gt: data.gt,
                challenge: data.challenge,
                new_captcha: data.new_captcha,
                product: "embed", // 产品形式，包括：float，embed，popup。注意只对PC版验证码有效
                offline: !data.success // 表示用户后台检测极验服务器是否宕机，一般不需要关注
                // 更多配置参数请参见：http://www.geetest.com/install/sections/idx-client-sdk.html#config
            }, handlerEmbed);
        }
    });
	
	
	
	
</script>  
  
  

</p>




</p>


[⬇🔔最新公告🔔⬇]
    <!-- 调用最新1条碎语 开始 -->
<div id="t">
<?php global $CACHE; $newtws_cache = $CACHE->readCache('newtw'); ?>
<a href="<?php echo BLOG_URL; ?>/t/"><?php echo $newtws_cache [ 0 ][content];?></a>
</div>
<!-- 调用最新1条碎语 结束 -->
</div>



<?php
 $sta_cache = Cache::getInstance()->readCache('sta');
 ?>
 日志 <?php echo $sta_cache['lognum']; ?> 篇
 评论 <?php echo $sta_cache['comnum_all']; ?> 条
 公告 <?php echo $sta_cache['twnum']; ?> 条
 运行 <?php echo floor((time()-strtotime(20180629))/86400); ?> 天
  
  
  </p>
  
  
  <a>友情链接：</a>
<?php {global $CACHE;$link_cache = $CACHE->readCache('link');?>
<?php foreach($link_cache as $value): ?>
<a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a>
<?php endforeach; ?>
<?php }?>


</p>
  
  <i class="fa fa-html5"></i> Copyright&nbsp;©&nbsp;2017-<?php echo date('Y',time())?>&nbsp;<?php echo $blogname; ?>
  <div class="copyright">&nbsp;&nbsp;<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>&nbsp;|&nbsp;<?php echo $footer_info; ?>
    <?php doAction('index_footer'); ?>
    &nbsp;|&nbsp;娃娃团队提供技术支持 <a href="https://8i9j.cn/" title="" target="_blank">娃娃电脑维修</a>&nbsp;不忘初心&nbsp;|&nbsp;<?php echo strtoupper(runtime_display()); ?>&nbsp;|&nbsp;版权：<a href=" " title="" target="_blank">wawaCM[娃娃团队]</a></div>
  </address>
</footer>
<script><?php if(_g('eqi')==1):?>eqi="ul:first";<?php else: ?>eqi="ul:first<?php for($i = 1; $i <= _g('eqi'); $i++) {echo ",ul:eq(".$i.")";}?>";<?php endif;?><?php if(_g('clsqkg')==1):?>blog="<?php echo _g('clsq');?>";<?php else: ?>blog="<?php echo $site_title; ?>";<?php endif;?>function pjaxfooter(){<?php echo _g('pjaxdm');?>}<?php if(_g('cnzz')==1):?>_czc.push(["_trackPageview",window.location.pathname,document.location.href]);<?php endif;?></script>
<?php if(_g('loading')==1):?>
<script type="text/javascript" src="https://cdnjs.yava.pw/hf99/20181125/js/mb/js/pace.min.js?v=20160704"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.yava.pw/hf99/20181125/css/mb/style/pace14.css" />
<div class="colorful_loading_frame"></div>
<?php else: ?>
<link rel="stylesheet" type="text/css" href="https://cdnjs.yava.pw/hf99/20181125/css/mb/style/loading.css" />
<div class="colorful_loading_frame">
  <div class="colorful_loading"><i class="rect1"></i><i class="rect2"></i><i class="rect3"></i><i class="rect4"></i><i class="rect5"></i></div>
</div>
<?php endif;?>
<?php empty($_COOKIE['myhk_bg']) ? $bgimgsrc = TEMPLATE_URL . 'images/bg/' . rand(1, 10) . '.jpg?v=new' : $bgimgsrc = TEMPLATE_URL . 'images/bg/' . $_COOKIE["myhk_bg"] . '.jpg' ;?>
<img class="bg-image" src="<?php echo $bgimgsrc; ?>" /><div class="bg-image-pattern"></div>
<script type="text/javascript" src="https://cdnjs.yava.pw/hf99/20181125/js/mb/js/realgravatar.js"></script>
<script type="text/javascript" src="https://cdnjs.yava.pw/hf99/20181125/css/mb/style/highslide/highslide.js?v=20150310"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.yava.pw/hf99/20181125/css/mb/style/highslide/highslide.css?v=20141026" />
<?php if(_g('pjax')==1):?>
<script type="text/javascript" src="https://cdnjs.yava.pw/hf99/20181125/js/mb/js/pjax.min.js?v=20170203"></script>
<script type="text/javascript" src="https://cdnjs.yava.pw/hf99/20181125/js/mb/js/global-pjax.js?v=20170216"></script>
<?php else: ?>
<script type="text/javascript" src="https://cdnjs.yava.pw/hf99/20181125/js/mb/js/global.js?v=20150912"></script>
<?php endif;?>
<?php doAction('myhk_player'); ?>
<?php if(isset($_GET["music"])):?>
<script>setTimeout(function() {play(<?php echo $_GET["music"]; ?>);}, 5000)</script>
<?php endif;?>
</body>
</html>