<?php
					$config =  array(
						"site" => "hf99.top",
						"token" => "59rR3NtGaGWJ2ZPQ",
						"log_number" => "20" 
					);