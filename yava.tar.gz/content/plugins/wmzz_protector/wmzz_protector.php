<?php
/*
Plugin Name: 站点安全防护-铜墙铁壁
Version: 2.1
Plugin URL: http://www.dyboy.top/post-138.html
Description: 此程序将对站点进行防黑客攻击保护,防xss，过滤危险的参数。小东负责搬砖...
Author: 大佬无名智者-小东搬砖-_-
Author URL: http://zhizhe8.net
*/
!defined('EMLOG_ROOT') && exit('fuck♂you');

define('WMZZ_PROT_ROOT',EMLOG_ROOT.'/content/plugins/wmzz_protector/');
include_once(WMZZ_PROT_ROOT.'wmzz_prot_set.php');
function wmzz_protector_content() { 
	include(WMZZ_PROT_ROOT.'protector.php');
}
function wmzz_protector_menu() { 
	echo '<div class="sidebarsubmenu" id="wmzz_protector"><a href="./plugin.php?plugin=wmzz_protector">站点安全保护</a></div>'; }
addAction('index_head','wmzz_protector_content');
addAction('adm_sidebar_ext', 'wmzz_protector_menu');
?>