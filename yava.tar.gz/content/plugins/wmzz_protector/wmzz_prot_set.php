<?php
!defined('EMLOG_ROOT') && exit('fuck♂you');
define('WMZZ_PROT_LOG', 1);
define('WMZZ_PROT_SWITCH', 1);
define('WMZZ_PROT_POST', 1);
define('WMZZ_PROT_GET', 1);
define('WMZZ_PROT_COOKIE', 1);
define('WMZZ_PROT_REFERRE', 1);
define('WMZZ_PROT_COPY', 1);
?>