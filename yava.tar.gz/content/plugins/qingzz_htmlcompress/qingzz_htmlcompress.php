<?php
/**
 * Plugin Name:小指分享-HTML压缩插件
 * Version: 1.0
 * Plugin URL: http://www.qingzz.cn/emlog_qingzz_blockIP
 * Description: 该插件主要是用来压缩HTML～
 * Author: 娃娃
 * Author Email: qingzz@qingzz.cn
 * Author URL: http://auv.qingzz.cn/
 */

!defined('EMLOG_ROOT') && exit('access deined!');

function qingzz_htmlcompress($buffer)
{
        include(EMLOG_ROOT.'/content/plugins/qingzz_htmlcompress/html-minify.php');
        echo html_minify_buffer($buffer);
}

function qingzz_htmlcompress_menu() {
  echo '<div class="sidebarsubmenu" id="qingzz_htmlcompress"><a href="./plugin.php?plugin=qingzz_htmlcompress">HTML压缩</a></div>';
}

addAction('qingzz_htmlcompress_hook','qingzz_htmlcompress');
addAction('adm_sidebar_ext', 'qingzz_htmlcompress_menu');