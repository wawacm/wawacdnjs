<?php
/**
 * Plugin Name:小指分享-HTML压缩插件
 * Version: 1.0
 * Plugin URL: http://www.qingzz.cn/emlog_qingzz_blockIP
 * Description: 该插件主要是用来压缩HTML～
 * Author: 娃娃
 * Author Email: qingzz@qingzz.cn
 * Author URL: http://auv.qingzz.cn/
 */

!defined('EMLOG_ROOT') && exit('access deined!');
function plugin_setting_view(){
	echo <<<HTML
	<h5>插件使用方法：</h5>
	<p><b>注意激活和卸除方法顺序不可改变！！！</b></p>
	<p>安装后首先点击激活</p>
	<p>然后找到include/lib/view.php里面</p>
	<pre>echo &#36;content;</pre>
	<p>将其修改为：</p>
	<pre>doAction('qingzz_htmlcompress_hook',&#36;content);</pre>
	<h5>卸载顺序：</h5>
	<p>首先找到include/lib/view.php里面修改过的那一行恢复</p>
	<p>然后到插件管理页面删除</p>
HTML;
}