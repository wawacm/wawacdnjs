<?php 
/**
*  Geetest配置文件
* @author Tanxu
*/
define("CAPTCHA_ID", "0e842a0f8ff9b4cc3713635f46e52ca8");
define("PRIVATE_KEY", "789fce08cb50277ed9062928530b9c08");



 ?>